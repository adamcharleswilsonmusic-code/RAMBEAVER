/* Modified for the local Fart Machine One / Beaver game derivative, 2026-10-13. Upstream origin and notices: LICENSING.md and provenance/source-inventory.json. */
/* SPDX-License-Identifier: GPL-3.0-only */
#include "game.c"
#include "capture_state.h"
#include "game_art.c"
