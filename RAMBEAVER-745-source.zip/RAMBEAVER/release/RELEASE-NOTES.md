# RAMBEAVER745

RAMBEAVER is a complete FM-1 action game: forest traversal and dam defense, a robot-smashing motorcycle ride, rooftop jetpack flight, optional side rooms, a data-center boss, and a forest epilogue. A flawless fresh run unlocks Golden Beaver.

Build 745 clips forest ground texture to solid-ground edges. It retains separated jetpack-head launches, the sixth-kill “Witness me” cadence, exact-progress saves, and the two-confirm golden ending flow. The matching browser viewer includes Record / Stop & Export for full device video with direct FM-1 USB audio on macOS.

Assets for publication: RAMBEAVER-FM-1_745.fwsc, rambeaver-quick-start.pdf, RAMBEAVER-745-source.zip, SHA256SUMS, and release/manifest.json. Publish the corresponding source with the firmware and retain all component notices. Complete the publication checklist before making the candidate a public release.
