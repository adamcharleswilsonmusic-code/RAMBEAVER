# Publication checklist for RAMBEAVER745

Destination: https://github.com/adamcharleswilsonmusic-code/RAMBEAVER

Prepared locally; this folder does not publish itself or update an FM-1.

- [x] Exact installed745 firmware selected; historical release ZIPs excluded.
- [x] Corresponding firmware/platform/loader/DSP/font/package source and notices included.
- [x] Original song audio, raw microphone/playthrough recordings, private paths, checkpoints, SDK/compiler trees and credentials excluded.
- [x] Preview and recorder paths made portable; Record / Stop & Export retains direct FM-1 USB audio and Desktop output.
- [x] Quick-start guide updated for build 745 and current capture flow.
- [x] Clean firmware/browser rebuilds match745; private-path checks, guide rendering, portable recorder export and source archive verification passed. See release/validation.json.
- [x] Project owner identified the original song as “my song,” supplied their own voice recordings, and explicitly authorized public game release. This known session authorization covers inclusion of the existing score and voices; no fresh ownership confirmation is outstanding.
- [x] Vendor inputs rechecked: root Apache-2.0 license and pinned upstream credit evidence retained. No additional license/notice files occur in the three blobs’ directory ancestry. These opaque internals are not independently audited. Generated-image provenance is retained.
- [ ] Create a local commit, publish corresponding source to the destination, and attach the firmware, guide, source archive and checksums to a release.

Keep firmware identity745 and the matching 5016-byte capture viewer together. Do not run the inherited historical Pages publisher: it force-pushed a generated branch and targeted obsolete release naming. No publisher or automatic upload script is included in this candidate.
