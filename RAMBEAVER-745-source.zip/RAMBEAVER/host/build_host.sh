#!/bin/sh
# Modified for the local Fart Machine One / Beaver game derivative, 2026-10-13. Upstream origin and notices: LICENSING.md and provenance/source-inventory.json.
# SPDX-License-Identifier: GPL-3.0-only
# Build the OMNI host simulator (the whole app on this machine) into build/host/omni_host.
# Same sources as the firmware, -ffp-contract=off like the device (no fused multiply-add).
set -e
cd "$(dirname "$0")/.."
CC="${CC:-cc}"
mkdir -p build/gen build/host
python3 tools/gen_tables.py build/gen/felucca_tables.h
[ -f build/gen/felucca_font.h ] || python3 tools/gen_font.py build/gen/felucca_font.h >/dev/null
TEST_FLAGS=
if [ "${FMO_TEST_BANK:-0}" = 1 ]; then
    TEST_FLAGS='-DFMO_SAMPLE_BANK_HEADER="fmo_test_bank.h"'
fi
$CC $TEST_FLAGS -O2 -ffp-contract=off -std=c99 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter \
    -DOM_HOST -Ifirmware/src -Ifirmware/src/dsp -Ibuild/gen -o build/host/omni_host host/omni_host.c \
    firmware/src/dsp/omni.c -lm
echo "host: build/host/omni_host"
